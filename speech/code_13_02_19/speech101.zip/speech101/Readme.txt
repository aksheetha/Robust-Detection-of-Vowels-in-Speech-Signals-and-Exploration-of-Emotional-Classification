I think there is some problem with the pesq.p code as it was generated on an old version so it is having a bit of complications 
so i checked it and tried to solve it.

Now im sending you the cleanly running codes so what i want u to do is

save these in a completely different path on your computer far away from the prevoius files 

and give the paths of clean file and noise file correctly

and if u get any errors in a specific line try to evaluvate that command only and see whats the problem is.

the codes i want you to run are

main_GA.m
main_nlm.m
main_mss_spmo.m
main_ics.m
main_mmse_spzc.m

the kalu.m and weiner.m are yet to rectified so leave them 

please do as instructed and let me know if u hav any queries.
 
